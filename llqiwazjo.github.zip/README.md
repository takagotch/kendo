# kendo-react-stackblitz-app
This is a sample application built with KendoReact - a set of over 90+ UI components built from the ground-up specifically for React.

Steps to run:

1) npm(or yarn) install
2) npm start 
